import java.util.LinkedList;
import java.util.Queue;

public class BinaryTree {
	Node root;
	Queue<Node> q = new LinkedList<>();
	Queue<Node> tq = new LinkedList<>();

	public BinaryTree() {
		root = null;
	}

	public void addNode(char data) {
		Node temp = new Node();
		temp.value = data;
		if (root == null) {
			root = temp;
		} else if (q.peek().left == null) {
			q.peek().left = temp;
		} else {
			q.peek().right = temp;
			q.poll();
		}
		q.add(temp);
		return;

	}

	public void createLevelTree(String message) {
		for (int i = 0; i < message.length(); i++) {
			addNode(message.charAt(i));
		}
	}

	public void swapLevel(Node root, int level) {
		char data;
		if (root.right != null) {
			if (level % 2 == 0) {
				data = root.left.value;
				root.left.value = root.right.value;
				root.right.value = data;

			}
			swapLevel(root.left, level + 1);
			swapLevel(root.right, level + 1);
		}
		return;
	}

	public void swapAlter() {
		if (root != null) {
			swapLevel(root, 0);
		}
	}
	//EPHH&WMK
	public String levelTraversal() {
		String message = "";
		if(root == null) {
			return "";
		}
		tq.add(root);
		while (tq.isEmpty() == false) {
			message = message + tq.peek().value;
			if (tq.peek().left != null) {
				tq.add(tq.peek().left);
			} 
			if (tq.peek().right != null) {
				tq.add(tq.peek().right);
			}
			tq.poll();
		}
		return message;
	}

	public void recur(Node root, int space) {
		if (root.right != null) {
			recur(root.right, space + 1);
		}
		for (int i = 0; i < space; i++) {
			System.out.println("\t");
			System.out.println(root.value + "\n");
		}
		if (root.left != null) {
			recur(root.left, space + 1);
		}
		return;
	}

	public void print() {
		recur(root, 0);
	}
}

class Node {
	char value;
	Node left;
	Node right;

	Node(char value) {
		this.value = value;
		right = null;
		left = null;
	}

	public Node() {
		// TODO Auto-generated constructor stub
	}
}
