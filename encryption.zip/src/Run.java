import java.nio.file.Paths;

public class Run {

	public static void main(String[] args) {
		String path = Paths.get("").toAbsolutePath().toString() + "/message.txt";
		String path1 = Paths.get("").toAbsolutePath().toString() + "/encrypted.txt";
		Cipher c = new Cipher();
		c.encryptFile(path);
		c.decryptFile(path1);
	}

}
