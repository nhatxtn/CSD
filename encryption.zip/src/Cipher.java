import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Cipher {
	public static final String ANSI_RED = "\u001B[31m";
	public static final String ANSI_RESET = "\u001B[0m";
	public String firstLevelEncrypt(String message) {
		char[] brokenUp = message.toCharArray();
		for (int i = 1; i <= message.length(); i++) {
			if (i % 2 == 0)
				brokenUp[i - 1] = (char) ((brokenUp[i - 1] + (i - 1)) % 256);
			else
				brokenUp[i - 1] = (char) ((brokenUp[i - 1] + (i + 1)) % 256);
		}
		
		return String.valueOf(brokenUp);
	}

	public String secondLevelEncrypt(String message) {
		BinaryTree tree = new BinaryTree();
		tree.createLevelTree(message);
		tree.swapAlter();
		message = tree.levelTraversal();
		return message;
	}

	public String encrypt(String message) {
		if (message.length() == 0) {
			System.out.println("No data found!");
			return "";
		}
		message = firstLevelEncrypt(message);
		message = secondLevelEncrypt(message);
		return message;
	}
	
	public void encryptFile(String path) {
		ArrayList<String> listString = new ArrayList<String>();
		ArrayList<String> encrypted = new ArrayList<String>();
		File file = new File(path);
		try {
			Scanner sc = new Scanner(file);
			while(sc.hasNextLine()) {
				listString.add(sc.nextLine());
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for (String string : listString) {
			encrypted.add(encrypt(string));
		}
		System.out.println(ANSI_RED+ "Cipher text: "+ANSI_RESET);
		for (String string : encrypted) {

			System.out.println(string);

		}
		saveFile(encrypted);
	}
	String firstLevelDecrypt(String message){
		BinaryTree tree = new BinaryTree();
		tree.createLevelTree(message);
		tree.swapAlter();
		message = tree.levelTraversal();
		return message;
	}
	String secondLevelDecrypt(String message){
		char[] brokenUp = message.toCharArray();
		for (int i = 1; i <= message.length(); i++) {
				if (i % 2 == 0)
					brokenUp[i - 1] = (char) ((brokenUp[i - 1] - (i - 1)) % 256);
				else
					brokenUp[i - 1] = (char) ((brokenUp[i - 1] - (i + 1)) % 256);
			}

			return String.valueOf(brokenUp);
		}
		String decrypt(String message){
		if(message.length() == 0 ){
			System.out.println("No data found");
		return "";
		}
		message = firstLevelDecrypt(message);
		message = secondLevelDecrypt(message);
		return message;
		}

	public void decryptFile(String path) {
		ArrayList<String> listString = new ArrayList<String>();
		ArrayList<String> decrypted = new ArrayList<String>();
		File file = new File(path);
		try {
			Scanner sc = new Scanner(file);
			while(sc.hasNextLine()) {
				listString.add(sc.nextLine());
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		for (String string : listString) {
			decrypted.add(decrypt(string));
		}
		System.out.println(ANSI_RED + "Plain text: " +ANSI_RESET);
		for (String string : decrypted) {
			System.out.println(string);
		}
	}
	void saveFile(ArrayList<String> list){
		try {
			FileWriter fileWriter = new FileWriter("encrypted.txt");
			for (String a: list ) {
				fileWriter.write(a);
				fileWriter.write("\n");
			}
			fileWriter.close();
	} catch (Exception e){
			e.printStackTrace();
		}
	}
}

