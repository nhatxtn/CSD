package BTS;

public class TreeNode {
    int val;
    TreeNode left,right;
    public TreeNode(int x){
        val = x;
        left=right=null;
    }
}
