package BTS;

public class Print {
    void printInorder(TreeNode node)
    {
        if (node == null)
            return;

        /* first recur on left child */
        printInorder(node.left);

        /* then print the data of node */
        System.out.print(node.val + " ");

        /* now recur on right child */
        printInorder(node.right);
    }
    void printPostorder(TreeNode node){
        if (node == null) return;
        printPostorder(node.left);

        printPostorder(node.right);

        System.out.print(node.val + " ");
    }
    void printPreorder(TreeNode node){
        if (node == null) return;
        System.out.print(node.val + " ");
        /* then recur on left subtree */
        printPreorder(node.left);

        /* now recur on right subtree */
        printPreorder(node.right);
    }

}
