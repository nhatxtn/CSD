package BTS;
import java.util.Set;
import java.util.Stack;
import java.util.HashSet;

public class BinaryTree {
    TreeNode root ;
    public BinaryTree(){

    }
    static Set<TreeNode> set = new HashSet<>();
    static Stack<TreeNode> stack = new Stack<>();

    // Function to build tree using given traversal
    public TreeNode buildPreIn(int[] preorder, int[] inorder)
    {

        TreeNode root = null;
        for (int pre = 0, in = 0; pre < preorder.length;) {

            TreeNode node = null;
            do {
                node = new TreeNode(preorder[pre]);
                if (root == null) {
                    root = node;
                }
                if (!stack.isEmpty()) {
                    if (set.contains(stack.peek())) {
                        set.remove(stack.peek());
                        stack.pop().right = node;
                    }
                    else {
                        stack.peek().left = node;
                    }
                }
                stack.push(node);
            } while (preorder[pre++] != inorder[in] && pre < preorder.length);

            node = null;
            while (!stack.isEmpty() && in < inorder.length &&
                    stack.peek().val == inorder[in]) {
                node = stack.pop();
                in++;
            }

            if (node != null) {
                set.add(node);
                stack.push(node);
            }
        }

        return root;
    }

    public  TreeNode buildPostIn(int[] in, int[] post, int n)
    {



        // Initialise postIndex with n - 1
        int postIndex = n - 1;

        // Initialise root with null
        TreeNode root = null;

        for (int p = n - 1, i = n - 1; p >= 0; ) {

            // Initialise node with NULL
            TreeNode node = null;

            // Run do-while loop
            do {

                // Initialise node with
                // new Node(post[p]);
                node = new TreeNode((post[p]));

                // Check is root is
                // equal to NULL
                if (root == null) {
                    root = node;
                }

                // If size of set
                // is greater than 0
                if (stack.size() > 0) {

                    // If st.peek() is present in the
                    // set s
                    if (set.contains(stack.peek())) {
                        set.remove(stack.peek());
                        stack.peek().left = node;
                        stack.pop();
                    }
                    else {
                        stack.peek().right = node;
                    }
                }
                stack.push(node);

            } while (post[p--] != in[i] && p >= 0);

            node = null;

            // If the stack is not empty and
            // st.top().data is equal to in[i]
            while (stack.size() > 0 && i >= 0
                    && stack.peek().val == in[i]) {
                node = stack.peek();

                // Pop elements from stack
                stack.pop();
                i--;
            }

            // If node not equal to NULL
            if (node != null) {
                set.add(node);
                stack.push(node);
            }
        }

        // Return root
        return root;
    }
    public  TreeNode buildLevelIn(int[] inorder, int[] levelOrder, int iStart, int iEnd, int n) {
        if (n <= 0)
            return null;

        // First node of level order is root
        TreeNode root = new TreeNode(levelOrder[0]);

        // Search root in inorder
        int index = -1;
        for (int i = iStart; i <= iEnd; i++) {
            if (levelOrder[0] == inorder[i]) {
                index = i;
                break;
            }
        }

        // Insert all left nodes in hash table
        HashSet<Integer> s = new HashSet<>();
        for (int i = iStart; i < index; i++)
            s.add(inorder[i]);

        // Separate level order traversals
        // of left and right subtrees.
        int[] lLevel = new int[s.size()]; // Left
        int[] rLevel = new int[iEnd - iStart - s.size()]; // Right
        int li = 0, ri = 0;
        for (int i = 1; i < n; i++) {
            if (s.contains(levelOrder[i]))
                lLevel[li++] = levelOrder[i];
            else
                rLevel[ri++] = levelOrder[i];
        }

        // Recursively build left and right
        // subtrees and return root.
        root.left = buildLevelIn(inorder, lLevel, iStart, index - 1, index - iStart);
        root.right = buildLevelIn(inorder, rLevel, index + 1, iEnd, iEnd - index);
        return root;

    }

    // Function to print tree in Inorder
    void printInorder(TreeNode node)
    {
        if (node == null)
            return;

        /* first recur on left child */
        printInorder(node.left);

        /* then print the data of node */
        System.out.print(node.val + " ");

        /* now recur on right child */
        printInorder(node.right);
    }
    void printPostorder(TreeNode node){
        if (node == null) return;
        printPostorder(node.left);

        printPostorder(node.right);

        System.out.print(node.val + " ");
    }
    void printPreorder(TreeNode node){
        if (node == null) return;
        System.out.print(node.val + " ");
        /* then recur on left subtree */
        printPreorder(node.left);

        /* now recur on right subtree */
        printPreorder(node.right);
    }


    // driver program to test above functions
    public static void main(String[] args) {
        BinaryTree tree = new BinaryTree();

        int[] in = new int[]{ 4, 8, 2, 5, 1, 6, 3, 7 };
        int[] post =new int[] { 8, 4, 5, 2, 6, 7, 3, 1 };
        int[] pre = new int[] { 1, 2, 4, 8, 5 ,3, 6, 7 };
        int[] level= new int[] {1,2,3,4,8,5,6,7};
        int len = in.length;
        /*TreeNode root = tree.buildPreIn(pre, in);  //build from preorder and inorder
        System.out.println("Inorder: ");
        tree.printInorder(root);
        System.out.println();
        System.out.println("Preorder: ");
        tree.printPreorder(root);
        TreeNode root2 = tree.buildPostIn(in , post, len);  // build from postorder and inorder
        tree.printPreorder(root2);*/
        TreeNode root3 = tree.buildLevelIn(in , level ,0 , len-1 , len );// build from levelorder and inorder
        tree.printInorder(root3);

    }
}
