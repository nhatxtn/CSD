package BTS;

public class BinaryTreeTwo extends Print {
    TreeNode root ;
    static int preIndex = 0;
    TreeNode buildPreIn(int in[], int pre[], int inStrt, int inEnd)
    {
        if (inStrt > inEnd)
            return null;

        /* Pick current node from Preorder traversal using preIndex
           and increment preIndex */
        TreeNode tNode = new TreeNode(pre[preIndex++]);

        /* If this node has no children then return */
        if (inStrt == inEnd)
            return tNode;

        /* Else find the index of this node in Inorder traversal */
        int inIndex = search(in, inStrt, inEnd, tNode.val);

        /* Using index in Inorder traversal, construct left and
           right subtress */
        tNode.left = buildPreIn(in, pre, inStrt, inIndex - 1);
        tNode.right = buildPreIn(in, pre, inIndex + 1, inEnd);

        return tNode;
    }
    int search(int arr[], int strt, int end, int value)
    {
        int i;
        for (i = strt; i <= end; i++) {
            if (arr[i] == value)
                return i;
        }
        return i;
    }
    TreeNode buildPostIn(int[] in, int[] post, int inStrt,
                   int inEnd, int postStrt, int postEnd)
    {
        // Base case
        if (inStrt > inEnd)
            return null;

        /* Pick current node from Postorder traversal using
           postIndex and decrement postIndex */
        TreeNode node = new TreeNode(post[postEnd]);

        /* If this node has no children then return */
        if (inStrt == inEnd)
            return node;
        int iIndex = search(in, inStrt, inEnd, node.val);

        /* Using index in Inorder traversal, construct left
           and right subtrees */
        node.left = buildPostIn(
                in, post, inStrt, iIndex - 1, postStrt,
                postStrt - inStrt + iIndex - 1);
        node.right = buildPostIn(in, post, iIndex + 1, inEnd,
                postEnd - inEnd + iIndex,
                postEnd - 1);

        return node;
    }
    TreeNode buildLevelIn(TreeNode startNode, int[] levelOrder,
                       int[] inOrder, int inStart,
                       int inEnd)
    {

        // if start index is more than end index
        if (inStart > inEnd)
            return null;

        if (inStart == inEnd)
            return new TreeNode(inOrder[inStart]);

        boolean found = false;
        int index = 0;

        // it represents the index in inOrder array of
        // element that appear first in levelOrder array.
        for (int i = 0; i < levelOrder.length - 1; i++) {
            int data = levelOrder[i];
            for (int j = inStart; j < inEnd; j++) {
                if (data == inOrder[j]) {
                    startNode = new TreeNode(data);
                    index = j;
                    found = true;
                    break;
                }
            }
            if (found == true)
                break;
        }

        // elements present before index are part of left
        // child of startNode. elements present after index
        // are part of right child of startNode.
        startNode.setLeft(buildLevelIn(startNode, levelOrder, inOrder, inStart, index - 1));
        startNode.setRight(buildLevelIn(startNode, levelOrder, inOrder, index + 1, inEnd));

        return startNode;
    }


    /* Function to find index of value in arr[start...end]
       The function assumes that value is postsent in in[]
     */

    public static void main(String[] args) {
        BinaryTreeTwo treeTwo = new BinaryTreeTwo();
        int[] in = new int[]{ 4, 8, 2, 5, 1, 6, 3, 7 };
        int[] post =new int[] { 8, 4, 5, 2, 6, 7, 3, 1 };
        int[] pre = new int[] { 1, 2, 4, 8, 5 ,3, 6, 7 };
        int[] level= new int[] {1 ,2 ,3 ,4,8 ,5 ,6 ,7};
        int len = in.length;
        TreeNode root = treeTwo.buildPreIn(in , pre , 0 , len-1);
        TreeNode root2 = treeTwo.buildPostIn(in , post , 0 , len-1 ,0 ,len-1);
        TreeNode root3 = treeTwo.buildLevelIn(null, level, in, 0, in.length - 1);
        treeTwo.printInorder(root);
        System.out.println();
        treeTwo.printInorder(root2);
        System.out.println();
        treeTwo.printInorder(root3);
    }
}
