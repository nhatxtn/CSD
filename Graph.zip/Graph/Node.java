package Graph;

import java.util.Comparator;

public  class Node implements Comparable<Node> {
    public int label;
    public boolean visited = false;
    Node left,right;
    public Node(int label){
        this.label=label;
    }


    public int compareTo(Node that) {
        return Integer.compare(this.label, that.label);
    }
}
