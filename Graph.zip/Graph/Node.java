package Graph;

import java.util.Comparator;

public  class Node implements Comparable<Node> {
    public char label;
    public boolean visited = false;
    Node left,right;
    public Node(char label){
        this.label=label;
    }


    public int compareTo(Node that) {
        return Character.compare(this.label, that.label);
    }
}
