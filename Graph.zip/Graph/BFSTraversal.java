package Graph;

import java.util.*;
import java.util.stream.Collector;

public class BFSTraversal {
    public int vertex;       /* total number of vertices in the graph */

    public Queue<Integer> que;           /* maintaining a queue */

    ArrayList<LinkedList<Integer>> adj = new  ArrayList<>(vertex);
    BFSTraversal(int v)
    {
        vertex = v;
        //adj = new LinkedList[vertex];
        for (int i=0; i<v; i++)
        {
            adj.add(new LinkedList<Integer>());//implement an adjacency for each vertex
        }
        que = new LinkedList<Integer>();
    }
    void insertEdge(int v,int w)
    {
        adj.get(v).add(w);      /* adding an edge to the adjacency list (edges are bidirectional in this example) */
        adj.get(w).add(v);     //add this to make undirected graph
       }
    void printData(int n){
        System.out.print(n+ " ");
    }
    void BFS(int root)
    {
        boolean[] visited = new boolean[vertex];       /* initialize boolean array for holding the data */
        int a = 0;
        visited[root]=true;
        que.add(root);       /* root node is added to the top of the queue */
        Collections.sort(adj.get(root)); // sort ascending order
        while (!que.isEmpty())
        {
             root = que.poll();        /* remove and get the top element of the queue */
            printData(root);    /* print the top element of the queue */

            for (int i = 0; i < adj.get(root).size(); i++)  /* iterate through the linked list and push all neighbors into queue */
            {
                a = adj.get(root).get(i);
                if (!visited[a])      /* only insert visited into queue if they have not been explored already */
                {
                    visited[a] = true;
                    que.add(a);
                }
            }
        }
    }

    public static void main(String[] args)
    {
        BFSTraversal graph = new BFSTraversal(5);
        graph.insertEdge(1,2);
        graph.insertEdge(4,1);
        graph.insertEdge(2,3);
        graph.insertEdge(2,4);
        graph.insertEdge(3,3);
        System.out.println("Breadth First Traversal for the graph is:");
        graph.BFS(2);

    }
}
