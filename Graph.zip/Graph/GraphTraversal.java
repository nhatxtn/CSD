package Graph;

import java.util.*;

public class GraphTraversal {

    public Node rootNode;
    public ArrayList<Node> nodes = new ArrayList<>();
    public int[][] adjMatrix; // adjacency Matrix

    public void setRootNode(Node n) {
        rootNode = n;
    }

    public Node getRootNode() {
        return rootNode;
    }

    public void addNode(Node n) {
        nodes.add(n);
    }
    public void adjMatrix(){
        adjMatrix = new int[nodes.size()][nodes.size()];
    }
    public void connectNode(Node src, Node dst) {

        if(adjMatrix == null) {
            adjMatrix();
        }
        adjMatrix[nodes.indexOf(dst)][nodes.indexOf(src)] = 1;
        adjMatrix[nodes.indexOf(src)][nodes.indexOf(dst)] = 1;


    }
    private Node getUnvisitedChildNode(Node n) {
        int index = nodes.indexOf(n);
        int size = adjMatrix.length;
        for (int j = 0; j < size; j++)
            if (adjMatrix[index][j] == 1 && !((Node)nodes.get(j)).visited)
                return nodes.get(j);
        return null;
    }
    public List<Node> getNeighbors(Node n) {
        List<Node> neighbors = new ArrayList<>();

        for(int i = 0; i < nodes.size(); i ++) {
            if (adjMatrix[nodes.indexOf(n)][i] == 1 && !(nodes.get(i).visited))
             {
                neighbors.add(nodes.get(i));
            }
            Collections.sort(neighbors);
        }
        return neighbors;

    }
    public void bfs() {


        Queue<Node> queue = new LinkedList<Node>();

        queue.add(rootNode);

        while(!queue.isEmpty()) {

            Node node = queue.poll();
           printNode(node);
            node.visited = true;

            List<Node> neighbors = getNeighbors(node);

            for ( int i = 0; i < neighbors.size(); i ++) {
                Node n = neighbors.get(i);

                if (n != null && !n.visited) {
                    n.visited = true;
                    queue.add(n);

                }
            }

        }

    }
    public void dfs(Node n) {

        printNode(n);
        n.visited = true;
        List<Node> neighbors = getNeighbors(n);
        for (int i = 0; i < neighbors.size(); i ++) {
            Node node = neighbors.get(i);
            if(node != null && !(node.visited)) {
                dfs(node);
            }
        }

    }
    public void dfsStack() {

        Stack<Node> stack = new Stack<>();
        stack.add(rootNode);
        while(!stack.isEmpty()){
            Node node = stack.pop();

            if(!(node.visited)) {
                printNode(node);
                node.visited = true;
            }

            List<Node> neighbors = getNeighbors(node);
            Collections.sort(neighbors,Collections.reverseOrder());
            for (int i = 0; i < neighbors.size(); i++) {
                Node n = neighbors.get(i);
                if(n != null && !(n.visited)) {
                    stack.add(n);
                }
            }

        }

    }
    private void printNode(Node n) {
        System.out.print(n.label + " ");
    }
    private void reset() {
        for (Node n : nodes)
            n.visited = false;
    }

    public static void main(String[] args) {
        GraphTraversal g = new GraphTraversal();
        Node n0 = new Node(1);
        Node n1 = new Node(2);
        Node n2 = new Node(3);
        Node n3 = new Node(4);
        Node n4 = new Node(5);
        

        g.addNode(n0);
        g.addNode(n1);
        g.addNode(n2);
        g.addNode(n3);
        g.addNode(n4);

        g.connectNode(n0,n1);
        g.connectNode(n0,n2);
        g.connectNode(n0,n3);
        g.connectNode(n1,n4);


        for (Node n : g.nodes) {
            g.setRootNode(n);

            System.out.print("From node ");
            g.printNode(n);

            System.out.print("\nDFS (iterative): ");
            g.dfsStack();
            g.reset();

            System.out.print("\nDFS (recursive): ");
            g.dfs(g.getRootNode());
            g.reset();

            System.out.print("\nBFS (iterative): ");
            g.bfs();
            g.reset();
            System.out.println("\n");
        }
    }


    }


